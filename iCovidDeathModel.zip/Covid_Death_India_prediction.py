import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model
import matplotlib.pyplot as pyplot
from matplotlib import style
import pickle

data = pd.read_csv("Latest Covid-19 India Status.csv")  # open dataset and save it into data
data = data[["Total Cases", "Active", "Discharged", "Deaths"]]  # save only these pieces of data into data

print(data)
# predict variable holds data we want to predict
predict = "Deaths"

X = np.array(data.drop(columns=[predict]))  # input variable for linear regression algo
y = np.array(data[predict])  # output variable for linear regression algo

X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size=0.2)  # Split data to
# train model using input/output and test data input/output which will be used to test accuracy of the model (20%
# data reserved for testing)

'''best = 0
for _ in range(500):
    X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size=0.2)  # Split data to
    # train model using input/output and test data input/output which will be used to test accuracy of the model (20%
    # data reserved for testing)

    linear = linear_model.LinearRegression()  # create a Linear Regression Model

    linear.fit(X_train, y_train)  # Use train data to train model to find th best fit line on a plotted graph (will help
    # predict by best fit line)

    acc = linear.score(X_test, y_test)  # check accuracy of model using score function, save the result to acc variable
    # to output
    
    print(acc)

    if acc > best:
        best = acc
        with open("iCovidDeathModel.pickle", "wb") as f:
            pickle.dump(linear, f)'''

pickle_in = open("iCovidDeathModel.pickle", "rb")
linear = pickle.load(pickle_in)

predictions = linear.predict(X_test)  # Make a prediction using the linear model

print("Covid Death Prediction     ", "     Input data     ", "Correct Output  ")  # print labels
print("----------------------------------------------------------")  # print
for x in range(len(predictions)):  # for loop prints prints test data fed to model and predictions it has made based
    # on what its learned prior. it also prints the correct output so the user can compare it with the prediction to
    # asses accuracy.
    print(predictions[x], X_test[x], y_test[x])

p = "Total Cases"
style.use("ggplot")
pyplot.scatter(data[p], data["Deaths"])
pyplot.xlabel(p)
pyplot.ylabel("Total Deaths")
pyplot.show()
""" This small project is a machine learning model that is using a dataset containing the temperature and salinity of
water. The models purpose is to correctly predict the temperature of water based on its salinity. Currently the
models average success rate is 39% Interestingly enough, the more data added to the set the lower the success rate
becomes. I would, guess that this could indicate that the data is random enough in terms of the salinity to water
temperature to where more data other than salinity would be required in order to increase the models ability to
predict a waters temperature """


import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model

data = pd.read_csv("bottle.csv")  # save dataset file to data
data = data[["Depthm", "T_degC", "Salnty"]]  # save only degrees and salinity columns into data


predict = "T_degC"  # degrees of the water will be the value we want our linear regression model to predict

X = np.array(data.drop(columns=[predict]))  # X is our input and stores the salinity column
y = np.array(data[predict])  # y is our output and stores the temperatures column

avg_acc = 0  # average accuracy

for x in range(5000):  # run the test and training 5000 times
    X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size=0.2)  # set out
    # input/output test and trains which will be used to both train an test the model. 20% of the dataset will be
    # reserved for testing

    linear = linear_model.LinearRegression()  # our model will be a linear regression algorithm
    linear.fit(X_train, y_train)  # train our model to use a best fit line to predict the temperature of water based
    # on salinity
    acc = linear.score(X_test, y_test)  # get the accuracy of our model
    avg_acc = avg_acc + acc  # add accuracy's together to later get the average acc


avg_acc = avg_acc/5000  # calculate average accuracy

print(avg_acc)  # print accuracy

predictions = linear.predict(X_test)
for x in range(len(predictions)):
    print(predictions[x], X_test[x], y_test[x])





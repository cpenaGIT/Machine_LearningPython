import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model
import matplotlib.pyplot as pyplot
from matplotlib import style

data = pd.read_csv('Summary of Weather.csv')  # get dataset and store it in data
data = data[["MaxTemp", "MinTemp"]]  # only get min and max temp columns
predict = "MaxTemp"  # this column label is the one we want our model to predict

X = np.array(data.drop(columns=[predict]))  # input array  for  model excludes the predict column
y = np.array(data[predict])  # output array containing the prediction column

X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size=0.2)  # split data to
# test and train both input/output and set 20% of data for testing.

linear = linear_model.LinearRegression()  # create a linear regression model

linear.fit(X_train, y_train)  # train the model using input/output

acc = linear.score(X_test, y_test)  # test model for accuracy and save it to the accuracy variable (acc)

print(acc)  # print the models prediction accuracy

predictions = linear.predict(X_test)  # save models predictions

for x in range (len(predictions)):  # print all predictions, test data used and correct outputs to screen
    print(predictions[x], X_test[x], y_test[x])


#  below code is used to display linear regression in a graph to visually see min temps correlation to max temp
p = "MinTemp"
style.use("ggplot")
pyplot.scatter(data[p], data["MaxTemp"])
pyplot.xlabel(p)
pyplot.ylabel("MaxTemp")
pyplot.show()

import pandas as pd
import sklearn
from sklearn import linear_model
import numpy as np
from matplotlib import pyplot as pyplot
import matplotlib.style as style

data = pd.read_csv("weatherHistory.csv")
data = data[["Temperature (C)", "Apparent Temperature (C)", "Humidity"]]
predict = "Apparent Temperature (C)"

X = np.array(data.drop(columns=[predict]))
y = np.array(data[predict])

X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size=0.2)

linear = linear_model.LinearRegression()

linear.fit(X_train, y_train)

acc = linear.score(X_test, y_test)

predictions = linear.predict(X_test)

for x in range(len(predictions)):  # print all predictions, test data used and correct outputs to screen
    print(predictions[x], X_test[x], y_test[x])

print(acc)

# this graph shows the relationship between humidity and apparent temp using a scatter plot
p = "Humidity"
style.use("ggplot")
pyplot.scatter(data[p], data["Apparent Temperature (C)"])
pyplot.xlabel(p)
pyplot.ylabel("Apparent Temperature (C)")
pyplot.fill = True
pyplot.show()

# this graph shows the relationship between humidity and temp using a scatter plot
p = "Humidity"
style.use("ggplot")
pyplot.scatter(data[p], data["Temperature (C)"])
pyplot.xlabel(p)
pyplot.ylabel("Temperature (C)")
pyplot.fill = True
pyplot.show()
